package com.itgate.demo.models;

import javax.persistence.Entity;

@Entity
public class Admin extends User {
}
