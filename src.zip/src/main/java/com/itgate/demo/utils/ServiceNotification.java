package com.itgate.demo.utils;

import com.itgate.demo.dao.ICandidatureRepository;
import com.itgate.demo.dao.INotificationRepository;
import com.itgate.demo.dao.IUser;
import com.itgate.demo.models.Candidature;
import com.itgate.demo.models.Notification;
import com.itgate.demo.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ServiceNotification {

    @Autowired
    public INotificationRepository notificationRepository;
    @Autowired
    public ICandidatureRepository candidatureRepository;

    public Notification NotifCandidatureAccept(Notification notification, Long id_candidature) {
        Candidature candidature = candidatureRepository.findOne(id_candidature);
        notification.setCandidature(candidature);
        notification.setType(" candidature Accepté");
        notification.setContenu("Votre candidature pour l'offre " +
                candidature.getOffre().getTitleoffer() +
                " Via " + candidature.getOffre().getSociete().getCompanyname()+"est acceptée"+
        " Vous avez un entretien le  :"+ candidature.getDateEntretien() + " sur le lien "+candidature.getLien());
        return notificationRepository.save(notification);
    }


    public Notification NotifCandidat(Notification notification, Long id_candidature) {
        Candidature candidature = candidatureRepository.findOne(id_candidature);
        notification.setContenu("Vous avez un entretien  "
                + candidature.getOffre().getTitleoffer() +
                " Via " + candidature.getOffre().getSociete().getCompanyname());
        return notificationRepository.save(notification);
    }

}
